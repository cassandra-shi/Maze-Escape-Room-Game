import random
from cmu_112_graphics import *
class Maze:

    def __init__(self, screenWidth, cellSize, rows, cols, margin):
        self.rows = rows
        self.cols = cols
        self.margin = margin
        self.width = screenWidth
        self.board = self.generateBoard()
        self.walls = self.generateWalls()
        self.cellSize = cellSize
        self.visited = set()
        self.backtracker((0,0), self.visited)
        self.checkUnvisited()

    def getWalls(self):
        return self.walls
    
    def getEntrance(self):
        return (self.margin, self.margin + self.cellSize //2)

    def generateBoard(self):
        board = []
        for row in range(self.rows):
            for col in range(self.cols):
                board.append((row,col))
        return board

    def generateWalls(self):
        walls = []
        for row in range(self.rows):
            for col in range(self.cols):
                walls.append(((row, col),(row, col + 1)))
                walls.append(((row, col),(row + 1, col)))
        for c in range(self.cols):
            walls.append(((self.rows,c), (self.rows, c + 1)))
            walls.append(((c, self.cols),(c + 1, self.cols)))
        walls.remove(((0,0),(1,0)))
        walls.remove(((self.rows - 1,self.rows),(self.rows, self.rows)))
        return walls
    
    def isPositionLegal(self, row, col):
        if row >= 0 and row < self.rows and col >= 0 and col < self.cols:
            return True
        else:
            return False

    def checkUnvisited(self):
        for row, col in self.board:
            if(row, col) not in self.visited:
                if col != 0:
                    self.walls.remove(((row, col),(row + 1, col)))
                else:
                    self.walls.remove(((row, col),(row, col + 1)))

    # the DFS generation algorithm is written based on the explanation from 
    # https://www.cs.cmu.edu/~112/notes/student-tp-guides/Mazes.pdf
    
    def backtracker(self, location, visited):
        visited.add(location)
        directions = [(0,1),(1,0),(-1,0),(0,-1)]
        for d in range(4):
            randomIndex = random.randint(0,len(directions)-1)
            direction = directions.pop(randomIndex)
            drow, dcol = direction
            curRow, curCol = location
            newRow, newCol = curRow + drow, curCol + dcol
            if self.isPositionLegal(newRow, newCol):
                if (newRow, newCol) in visited:
                    continue
                if direction == (0,1):
                    self.walls.remove(((newRow, newCol),(newRow + 1, newCol)))
                elif direction == (0, -1):
                    self.walls.remove(((curRow, curCol),(curRow + 1, curCol)))
                elif direction == (1, 0):
                    self.walls.remove(((newRow, newCol),(newRow, newCol + 1)))
                else:
                    self.walls.remove(((curRow, curCol),(curRow, curCol + 1)))
                location = (newRow, newCol)
                self.backtracker(location, visited)

    def drawWall(self, canvas, node1, node2):
        (x1, y1) = node1
        (x3, y3) = node2
        canvas.create_line(self.margin + y1 * self.cellSize, 
                        self.margin + x1 * self.cellSize, 
                        self.margin + y3 * self.cellSize,
                        self.margin + x3 * self.cellSize,
                        fill = 'black', width = 3)

    def drawMaze(self, canvas):
        for wall in self.walls:
            node1, node2 = wall
            self.drawWall(canvas, node1, node2)