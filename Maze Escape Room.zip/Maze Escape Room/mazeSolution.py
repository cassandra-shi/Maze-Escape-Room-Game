from cmu_112_graphics import *
from mazeGeneration import *

class mazeSolution():

    def __init__(self, walls, cellSize, rows, cols, margin):
        self.walls = walls
        self.cellSize = cellSize
        self.rows = rows
        self.cols = cols
        self.margin = margin

    def isPositionLegal(self, row, col):
        if row >= 0 and row < self.rows and col >= 0 and col < self.cols:
            return True
        else:
            return False
            
    def mazeMoveLegal(self, direction, curRow, curCol):
        dx, dy = direction
        (nextRow, nextCol) = curRow + dx, curCol + dy
        if self.isPositionLegal(nextRow, nextCol):
            if direction == (0,1):
                if ((nextRow, nextCol),(nextRow + 1, nextCol)) not in self.walls:
                    return True
            elif direction == (0, -1):
                if((curRow, curCol),(curRow + 1, curCol)) not in self.walls:
                    return True
            elif direction == (1, 0):
                if ((nextRow, nextCol),(nextRow, nextCol + 1)) not in self.walls:
                    return True
            elif direction == (-1, 0):
                if ((curRow, curCol),(curRow, curCol + 1)) not in self.walls:
                    return True
        return False  
    
    def solveMaze(self, startRow, startCol, endRow, endCol):
        result = self.solveMazeRecursion(startRow, startCol, endRow, endCol,
                        {}, [(startRow, startCol)], set((startRow, startCol)))
        cell = (endRow, endCol)
        path = {}
        solution = []
        while cell != (startRow, startCol):
            path[result[cell]] = cell
            cell = result[cell]
        for row, col in path:
            solution.append((row, col))
        return solution
    
    def getLength(self,startRow, startCol, endRow, endCol):
        result = self.solveMaze(startRow, startCol, endRow, endCol)
        return len(result)

    # The BFS searching algorithm was written based on the explanation from
    # youtube video without looking at the actual code:
    #  https://www.youtube.com/watch?v=D14YK-0MtcQ
    # The video introduces the iterative method and I modified it into a recursive
    # version.
    # check all possible direction each time for all current cells until find the target. 
    # Use dictionary to record all possible directions at this point
    def solveMazeRecursion(self, row, col, targetRow, targetCol, 
                       path, curMove, visited):
        if (row, col) == (targetRow, targetCol):
            return path
        else:
            row, col = curMove.pop()
            for drow, dcol in [(0,1),(1,0),(-1,0),(0,-1)]:
                if self.mazeMoveLegal((drow, dcol), row, col):
                    newRow, newCol = row + drow, col + dcol
                    if (newRow, newCol) in visited:
                        continue
                    visited.add((newRow, newCol))
                    curMove.append((newRow, newCol))
                    path[(newRow, newCol)] = (row, col)
            result = self.solveMazeRecursion(row, col, targetRow, targetCol, 
                    path, curMove, visited)
            if result != None:
                    return result

    def FillCell(self, canvas, row, col):
        canvas.create_rectangle(self.margin + col * self.cellSize,
                                self.margin + row * self.cellSize,
                                self.margin + (col + 1) * self.cellSize,
                                self.margin + (row + 1) * self.cellSize,
                                fill = 'blue', width = 0)

    def FillCellCoin(self, canvas, row, col):
        canvas.create_rectangle(self.margin + col * self.cellSize,
                                self.margin + row * self.cellSize,
                                self.margin + (col + 1) * self.cellSize,
                                self.margin + (row + 1) * self.cellSize,
                                fill = 'yellow', width = 0)
    
    def drawMazeSolution(self, canvas,startRow, startCol, endRow, endCol):
        path = self.solveMaze(startRow, startCol, endRow, endCol)
        for row, col in path:
            self.FillCell(canvas, row, col)
        self.FillCell(canvas, endRow, endCol)

    def drawMazeSolutionCoin(self, canvas,startRow, startCol, endRow, endCol):
        path = self.solveMaze(startRow, startCol, endRow, endCol)
        for row, col in path:
            self.FillCellCoin(canvas, row, col)
        self.FillCellCoin(canvas, endRow, endCol)