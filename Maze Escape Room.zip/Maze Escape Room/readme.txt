Project Description: Maze Escape Room
It’s an escape room game, in which the room is designed to be a maze. Players have to unlock all boxed in the maze and get out of the maze. Along the way out, players can collect coins to unlock boxes.

Run the project: run the mazeGame.py file in the folder

Libraries: None

Shortcuts: 
1. ‘h’ for the hint of maze solution from the entrance to the exit.
2. ‘c’ for the hind of the nearest coin.
3. ’s’ to indicate that you want to solve the puzzle to unlock the box when you are at the box.
4. ‘p’ to indicate that you want to pay coins to unlock the box when you are at the box.
5. ‘r’ to restart the game after winning the current game.