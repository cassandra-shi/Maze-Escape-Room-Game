from cmu_112_graphics import *
import random
import copy

class Sudoku:
    def __init__(self,image, num1, boardRows, boardCols, cellSize, margin, imageS, solve,otherPositions):
        self.puzzlePic = image
        self.solvePic = imageS
        self.solve = solve
        self.num = num1
        self.positions = []
        self.boardRows = boardRows
        self.boardCols = boardCols
        self.cellSize = cellSize
        self.boardMargin = margin
        self.otherPositions = otherPositions
        self.rows = 9
        self.cols = 9
        self.puzzleMargin = 200
        self.problems = {}
        self.generatePositions()
        self.gridSelect = False
        self.generateFillingProblems()

    def generateFillingProblems(self):
        self.fillingProblems = {}
        for position in self.positions:
            filling = {}
            puzzle = self.problems[position]
            for row in range(len(puzzle)):
                for col in range(len(puzzle[0])):
                    if puzzle[row][col] == 0:
                        filling[(row,col)] = ''
            self.fillingProblems[position] = filling

    def getPuzzlePositions(self):
        return self.positions

    def getPuzzles(self):
        return self.problems
    
    def generatePositions(self):
        num = 0
        while num < self.num:
            row = random.randint(0,self.boardRows - 1)
            col = random.randint(0,self.boardCols - 1)
            if (row,col) not in self.otherPositions:
                self.positions.append((row,col))
                num += 1
                board = [[0]*9 for row in range(9)]
                newBoard = self.generateSudoku(0,board)
                puzzleBoard = self.generatePuzzleBoard(newBoard)
                self.problems[(row,col)] = puzzleBoard
        
    def isFull(self,board):
        for row in board:
            for col in row:
                if col == 0:
                    return False
        return True
    
    def isValid(self,board,row,col,value):
        for x in range(9):
            if board[x][col] == value:
                return False
        for y in range(9):
            if board[row][y] == value:
                return False
        rowRegion = row // 3
        colRegion = col // 3
        for r in range(3):
            for c in range(3):
                if board[rowRegion * 3 + r][colRegion * 3 + c] == value:
                    return False
        return True
# Reference: https://lvngd.com/blog/generating-and-solving-sudoku-puzzles-python/
# Only referred to the steps listed in the website, without looking at the actual code.
    def generateSudoku(self,index,board):
        if self.isFull(board):
            return board
        else:
            row = index // 9
            col = index % 9
            if board[row][col] == 0:
                possNumbers = [1,2,3,4,5,6,7,8,9]
                random.shuffle(possNumbers)
                for num in possNumbers:
                    if self.isValid(board,row,col,num):
                        board[row][col] = num
                        result = self.generateSudoku(index + 1,board)
                        if result != None:
                            return result
                board[row][col] = 0
            return None
    
    def generatePuzzleBoard(self,board):
        puzzleBoard = copy.deepcopy(board)
        count = 0
        while count < 31:
            removeIndex = random.randint(0,80)
            row = removeIndex // 9
            col = removeIndex % 9
            if puzzleBoard[row][col] != 0:
                puzzleBoard[row][col] = 0
                count += 1
        return puzzleBoard
    
    def drawCell(self,canvas, row, col,num):
        canvas.create_rectangle(self.puzzleMargin + col * self.cellSize,
                                self.puzzleMargin + row * self.cellSize,
                                self.puzzleMargin + (col + 1) * self.cellSize,
                                self.puzzleMargin + (row + 1) * self.cellSize,
                                fill = 'white',outline = 'black', width = 1)
        if num != 0:
            canvas.create_text(self.puzzleMargin + (col + 0.5) * self.cellSize,
                                self.puzzleMargin + (row + 0.5) * self.cellSize, text = str(num), fill = 'black')
        if num == 0:
            canvas.create_rectangle(self.puzzleMargin + col * self.cellSize,
                                self.puzzleMargin + row * self.cellSize,
                                self.puzzleMargin + (col + 1) * self.cellSize,
                                self.puzzleMargin + (row + 1) * self.cellSize,
                                fill = 'cyan',outline = 'black', width = 1)

    def drawBoard(self, canvas,problem):
        canvas.create_rectangle(self.puzzleMargin - 40,self.puzzleMargin - 40,
                                self.puzzleMargin + self.cols * self.cellSize + 40,
                                self.puzzleMargin + self.rows * self.cellSize + 40, fill = 'gold')
        for row in range(self.rows):
            for col in range(self.cols):
                self.drawCell(canvas, row, col,problem[row][col])
        canvas.create_rectangle(self.puzzleMargin + self.cols // 2 * self.cellSize - 20, 
                                self.puzzleMargin + self.rows * self.cellSize + 5,
                                self.puzzleMargin + self.cols // 2 * self.cellSize + 30,
                                self.puzzleMargin + self.rows * self.cellSize + 30, fill = 'red', outline = 'black'
                                )
        canvas.create_text(self.puzzleMargin + self.cols // 2 * self.cellSize + 5,
                                self.puzzleMargin + self.rows * self.cellSize + 15,text = 'submit', fill = 'black')
        x1, y1 = self.puzzleMargin - 40,self.puzzleMargin - 40
        x2, y2 = self.puzzleMargin + self.cols * self.cellSize + 40, self.puzzleMargin + self.rows * self.cellSize + 40
        canvas.create_rectangle(x2 - 30, y1 + 10, x2 - 10, y1 + 30, fill = 'grey', outline = 'black')
        canvas.create_line(x2 - 30, y1 + 10,x2 - 10, y1 + 30, fill = 'black')
        canvas.create_line(x2 - 10,y1 + 10,x2 - 30, y1 + 30,fill = 'black')
        
    def closeWindow(self,event):
        x1, y1 = self.puzzleMargin - 40,self.puzzleMargin - 40
        x2, y2 = self.puzzleMargin + self.cols * self.cellSize + 40, self.puzzleMargin + self.rows * self.cellSize + 40
        leftx,topy = x2 - 30, y1 + 10
        rightx,bottomy = x2 - 10, y1 + 30
        if leftx <= event.x <= rightx and topy <= event.y <= bottomy:
            return True
        else:
            return False
            
    def cellToPosition(self, row, col):
        x = self.boardMargin + (col) * self.cellSize +  0.5 * self.cellSize
        y = self.boardMargin + (row) * self.cellSize +  0.5 * self.cellSize
        return (x,y)

    def redrawAll(self, canvas):
        for index in range(len(self.positions)):
            row, col = self.positions[index]
            x,y = self.cellToPosition(row, col)
            if not self.solve[index]:
                canvas.create_image(x, y, 
                                image=ImageTk.PhotoImage(self.puzzlePic))
            else:
                canvas.create_image(x, y, 
                                image=ImageTk.PhotoImage(self.solvePic))

    # from 112 Notes on the website
    def pointInGrid(self, x, y):
        return ((self.puzzleMargin <= x <= self.puzzleMargin + self.cols * self.cellSize) and
                (self.puzzleMargin <= y <= self.puzzleMargin + self.rows * self.cellSize))

    # from 112 Notes on the website
    def getCell(self, x, y):
        if (not self.pointInGrid(x, y)):
            return (-1, -1)
        row = int((y - self.puzzleMargin) / self.cellSize)
        col = int((x - self.puzzleMargin) / self.cellSize)
        return (row, col)
    
    def selectCell(self,event,puzzleBoard):
        row,col = self.getCell(event.x,event.y)
        if (row,col) != (-1,-1) and puzzleBoard[row][col] == 0:
            return (row,col)
    
    def colorCell(self,canvas,row,col):
        canvas.create_rectangle(self.puzzleMargin + col * self.cellSize,
                                self.puzzleMargin + row * self.cellSize,
                                self.puzzleMargin + (col + 1) * self.cellSize,
                                self.puzzleMargin + (row + 1) * self.cellSize,
                                fill = 'red',outline = 'black', width = 1)
    
    def drawFillingNum(self,canvas,fillingProblem):
        for (row,col) in fillingProblem:
            canvas.create_text(self.puzzleMargin + (col + 0.5) * self.cellSize,
                            self.puzzleMargin + (row + 0.5) * self.cellSize, text = fillingProblem[(row,col)], fill = 'black')

    def isSolutionValid(self, board):
        for row in board:
            if set(row) != {1,2,3,4,5,6,7,8,9}:
                print(row,'rowFalse')
                return False
        for col in range(9):
            colS = set()
            for row in range(9):
                colS.add(board[row][col])
            if colS != {1,2,3,4,5,6,7,8,9}:
                print(colS,'colFalse')
                return False
        for i in range(3):
            rowStart = i * 3 
            for j in range(3):
                colStart = j * 3 
                regionBoard = [[0]*3 for row in range(3)]
                for r in range(3):
                    for c in range(3):
                        regionBoard[r][c] = board[rowStart + r][colStart + c]
                region = set()
                for x in regionBoard:
                    for y in x:
                        region.add(y)
                if region != {1,2,3,4,5,6,7,8,9}:
                    print(region,'regionFalse')
                    return False
        return True
    

    def mouseSubmit(self,event):
        if (
            (self.puzzleMargin + self.cols // 2 * self.cellSize - 20 <= 
            event.x <= self.puzzleMargin + self.cols // 2 * self.cellSize + 30) and
            (self.puzzleMargin + self.rows * self.cellSize + 5 <= event.y <=
            self.puzzleMargin + self.rows * self.cellSize + 30)
        ):
            return True
        else:
            return False
    
    def solutionCheck(self,position):
        solutionCheck = copy.deepcopy(self.problems[position])
        for (row,col) in self.fillingProblems[position]:
            if self.fillingProblems[position][(row,col)] == '':
                return False
            solutionCheck[row][col] = int(self.fillingProblems[position][(row,col)])
        if self.isSolutionValid(solutionCheck):
            return True
        else:
            return False