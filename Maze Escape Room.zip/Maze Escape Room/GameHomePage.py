from cmu_112_graphics import *

def drawHomePage(app, canvas):
    canvas.create_image(450,450,image=ImageTk.PhotoImage(app.image2))
    canvas.create_text(app.width/2, 100, text = 'Maze Escape Room',
                       fill = 'black', font='Helvetica 40 bold')
    canvas.create_rectangle(300, 200,
                            300 + app.boxWidth, 
                            200 + app.boxHeight//2, 
                            fill = 'sandybrown', outline = 'black',
                            width = 5)
    canvas.create_text(300 + app.boxWidth /2 , 200 + app.boxHeight/4, 
                       text = 'Instruction', fill = 'black',
                       font='Helvetica 20 bold', anchor = 'center')
    canvas.create_rectangle(300, 200 + app.margin + app.boxHeight/4,
                            300 + app.boxWidth, 200 + 
                            app.boxHeight + app.margin+ app.boxHeight/4,
                            fill = 'sandybrown', outline = 'black',
                            width = 5)
    canvas.create_text(300 + app.boxWidth /2, 200 + app.margin + app.boxHeight/2 
                       + app.boxHeight/4, text = 'Level 1', 
                        fill = 'black', font = 'Helvetica 25 bold'
                       , anchor = 'center')
    canvas.create_rectangle(300, 200 + 2*app.margin + app.boxHeight,
                            300 + app.boxWidth, 200 + 2*app.boxHeight + 2*app.margin,
                            fill = 'sandybrown', outline = 'black',
                            width = 5)
    canvas.create_text(300 + app.boxWidth /2, 200 + 2*app.margin + 1.25*app.boxHeight
                       + app.boxHeight/4, text = 'Level 2', 
                        fill = 'black', font = 'Helvetica 25 bold'
                       , anchor = 'center')
    
def getLevel1(app):
    return (300, 200 + app.margin + app.boxHeight/4,
            300 + app.boxWidth, 200 + app.boxHeight + app.margin+ app.boxHeight/4)

def getLevel2(app):
    return (300, 200 + 2*app.margin + app.boxHeight,
            300 + app.boxWidth, 200 + 2*app.boxHeight + 2*app.margin,)
    
def getInstruction(app):
    return (300, 200,300 + app.boxWidth,200 + app.boxHeight//2, )