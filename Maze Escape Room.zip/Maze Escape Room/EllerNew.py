import random
from cmu_112_graphics import *
from mazeSolution import *
from mazeCharacter import *

class EllerMaze:
    def __init__(self, rows, cols, margin, cellSize):
        self.rows = rows
        self.cols = cols
        self.boardC = []
        self.board = self.generateBoard()
        self.walls = self.generateWalls()
        self.ellerGeneration()
        self.margin = margin
        self.cellSize = cellSize
    
    def getWalls(self):
        return self.walls

    def findCurrSet(self, position):
        (r,c) = position
        for existedSet in self.boardC:
            if (r,c) in existedSet:
                return existedSet
    
    def mergeSets(self, currSet, nextSet):
        for sets in self.boardC:
            if sets == currSet:
                for element in nextSet:
                    sets.add(element)
                self.boardC.remove(nextSet)
    
    def findRowCells(self, existedSet, rowTarget):
        result = []
        for s in existedSet:
            row,col = s
            if row == rowTarget:
                result.append((row, col))
        return result

    def generateBoard(self):
        board = []
        for row in range(self.rows):
            for col in range(self.cols):
                board.append((row,col))
        return board

    def generateWalls(self):
        walls = []
        for row in range(self.rows):
            for col in range(self.cols):
                walls.append(((row, col),(row, col + 1)))
                walls.append(((row, col),(row + 1, col)))
        for c in range(self.cols):
            walls.append(((self.rows,c), (self.rows, c + 1)))
            walls.append(((c, self.cols),(c + 1, self.cols)))
        walls.remove(((0,0),(1,0)))
        walls.remove(((self.rows - 1,self.rows),(self.rows, self.rows)))
        return walls  
    # Refer to the steps mentioned in the website: 
    # https://weblog.jamisbuck.org/2010/12/29/maze-generation-eller-s-algorithm
    # without looking at the actual codes
    # Randomly merge different set together at each row and merge all different set together at the last row.
    def ellerGeneration(self):
        for r in range(self.rows):
            for c in range(self.cols):
                flag = True
                for possSet in self.boardC:
                    if (r,c) in possSet:
                        flag = False
                        continue
                if flag:
                    self.boardC.append({(r,c)})
            if r < self.rows - 1:
                for c in range(self.cols - 1):
                    if self.findCurrSet((r,c)) != self.findCurrSet((r,c + 1)):
                        remove = random.randint(0,1)
                        if remove == 1:
                            currSet = self.findCurrSet((r,c))
                            nextSet = self.findCurrSet((r,c + 1))
                            self.mergeSets(currSet, nextSet)
                            self.walls.remove(((r, c + 1),(r + 1, c + 1)))
                for existedSet in self.boardC:
                    s = self.findRowCells(existedSet, r)
                    count = len(s)
                    while count > len(s) - 1:
                        for ele in s:
                            removeD = random.randint(0,1)
                            if removeD == 1:
                                count -= 1
                                for existSet in self.boardC:
                                    if ele in existSet:
                                        rc, cc = ele
                                        existedSet.add((rc + 1, cc))
                                        self.walls.remove(((rc + 1, cc),(rc + 1, cc + 1)))
            else:
                for c in range(self.cols - 1):
                    if self.findCurrSet((r,c)) != self.findCurrSet((r,c + 1)):
                        remove = 1
                        if remove == 1:
                            currSet = self.findCurrSet((r,c))
                            nextSet = self.findCurrSet((r,c + 1))
                            self.mergeSets(currSet, nextSet)
                            self.walls.remove(((r, c + 1),(r + 1, c + 1)))


    def drawWall(app, canvas, node1, node2):
        (x1, y1) = node1
        (x3, y3) = node2
        canvas.create_line(app.margin + y1 * app.cellSize, 
                        app.margin + x1 * app.cellSize, 
                        app.margin + y3 * app.cellSize,
                        app.margin + x3 * app.cellSize,
                        fill = 'black', width = 3)

    def drawMaze(self, canvas):
        for wall in self.walls:
            node1, node2 = wall
            self.drawWall(canvas, node1, node2)  
                


            