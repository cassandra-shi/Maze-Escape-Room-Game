from cmu_112_graphics import *
import random

class Coin:
    def __init__(self, image, num, rows, cols, cellSize, margin):
        self.coinstrip = image
        self.coins = []
        for i in range(6):
            sprite = self.coinstrip.crop((32*i, 0, 32*(i+1), 32))
            self.coins.append(sprite)
        self.spriteCounter = 0
        self.num = num
        self.positions = []
        self.rows = rows
        self.cols = cols
        self.cellSize = cellSize
        self.margin = margin
        self.generateCoinPosition()

    def generateCoinPosition(self):
        for i in range(self.num):
            row = random.randint(0,self.rows - 1)
            col = random.randint(0,self.cols - 1)
            self.positions.append((row, col))
    
    def getCoinPositions(self):
        return self.positions


    def cellToPosition(self, row, col):
        x = self.margin + (col) * self.cellSize +  0.5 * self.cellSize
        y = self.margin + (row) * self.cellSize +  0.5 * self.cellSize
        return (x,y)

    def timerFired(self):
        self.spriteCounter = (1 + self.spriteCounter) % len(self.coins)
        
    def getCoinImage(self):
        return self.coins[0]

    def redrawAll(self, canvas):
        sprite = self.coins[self.spriteCounter]
        for row, col in self.positions:
            x,y = self.cellToPosition(row, col)
            canvas.create_image(x, y, 
                            image=ImageTk.PhotoImage(sprite))


    
