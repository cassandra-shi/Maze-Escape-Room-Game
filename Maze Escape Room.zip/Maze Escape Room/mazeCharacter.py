from cmu_112_graphics import *
from mazeGeneration import *

class Character():
    def __init__(self, image, walls, cellSize, entrance,rows, cols, margin):
        self.image = image
        self.characterWidth,self.characterHeight = image.size
        self.walls = walls
        self.cellSize = cellSize
        positionX, positionY = entrance
        self.characterPositionX = positionX
        self.characterPositionY = positionY
        self.rows = rows
        self.cols = cols
        self.margin = margin

    # from 112 Notes on the website
    def pointInGrid(self, x, y):
        return ((self.margin <= x <= self.margin + self.cols * self.cellSize) and
                (self.margin <= y <= self.margin + self.rows * self.cellSize))
    # from 112 Notes on the website
    def getCell(self, x, y):
        if (not self.pointInGrid(x, y)):
            return (-1, -1)
        row = int((y - self.margin) / self.cellSize)
        col = int((x - self.margin) / self.cellSize)
        return (row, col)

    def getCharacterPosition(self):
        curRow, curCol = self.getCell(self.characterPositionX, 
        self.characterPositionY)
        return (curRow,curCol) 

    def characterMoveLegal(self, dx, dy):
        curRow, curCol = self.getCell(self.characterPositionX, 
        self.characterPositionY)
        nextRow, nextCol = self.getCell(self.characterPositionX + dx, 
        self.characterPositionY + dy)
        if (nextRow, nextCol) == (-1, -1): 
            return False
        if (curRow, curCol) == (nextRow, nextCol):
            return True 
        else:
            direction = (nextRow - curRow, nextCol - curCol)
            if direction == (0,1):
                if ((nextRow, nextCol),(nextRow + 1, nextCol)) not in self.walls:
                    return True
                return False
            elif direction == (0, -1):
                if((curRow, curCol),(curRow + 1, curCol)) not in self.walls:
                    return True
                return False
            elif direction == (1, 0):
                if ((nextRow, nextCol),(nextRow, nextCol + 1)) not in self.walls:
                    return True
                return False
            elif direction == (-1, 0):
                if ((curRow, curCol),(curRow, curCol + 1)) not in self.walls:
                    return True
                return False

    def notOnWall(self, dx, dy):
        top = self.getCell(self.characterPositionX, 
            self.characterPositionY - self.characterHeight // 2)
        bottom = self.getCell(self.characterPositionX, 
            self.characterPositionY + self.characterHeight // 2)
        left = self.getCell(self.characterPositionX - self.characterWidth // 2, 
            self.characterPositionY)
        right = self.getCell(self.characterPositionX + self.characterWidth // 2, 
            self.characterPositionY)
        if dx != 0:
            if top != bottom:
                bodyL = self.getCell(self.characterPositionX - self.characterWidth // 2 + dx, self.characterPositionY)
                bodyR = self.getCell(self.characterPositionX + self.characterWidth // 2 + dx, self.characterPositionY)
                if bodyL != bodyR:
                    return False
        if dy != 0:
            if left != right:
                bodyT = self.getCell(self.characterPositionX, self.characterPositionY - self.characterHeight // 2 + dy)
                bodyB = self.getCell(self.characterPositionX, self.characterPositionY + self.characterHeight // 2 + dy)
                if bodyT != bodyB:
                    return False 
        return True  
    
    def keyPressed(self,event):
        step = 5
        if event.key == 'Right':
            if self.characterMoveLegal(step + self.characterHeight // 2, 0) and self.notOnWall(step, 0):
                    self.characterPositionX += step
        if event.key == 'Left': 
            if self.characterMoveLegal(-step - self.characterWidth, 0) and self.notOnWall(-step, 0):
                    self.characterPositionX -= step
        if event.key == 'Down':
            if self.characterMoveLegal(0, step + self.characterHeight // 2) and self.notOnWall(0, step):
                    self.characterPositionY += step
        if event.key == 'Up' :
            if self.characterMoveLegal(0, -step - self.characterHeight // 2) and self.notOnWall(0, -step):
                    self.characterPositionY -= step
    
    def drawCharacter(self,canvas):
        canvas.create_image(self.characterPositionX, 
                    self.characterPositionY, 
                    image=ImageTk.PhotoImage(self.image))