from cmu_112_graphics import *
from mazeGeneration import *
from mazeCharacter import *
from mazeSolution import *
from GameHomePage import *
from coin import *
from EllerNew import *
from puzzle import *
from sudoku import *

def appStarted(app):
    app.rows = 15
    app.cols = 15
    app.margin = 100
    app.instruction = False
    app.cellSize = (app.width - 300) // 15
    app.puzzlePic = app.loadImage('box.png')
    app.imageBox = app.scaleImage(app.puzzlePic, 2)
    app.puzzleS = app.loadImage('boxSolved.png')
    app.imageBoxS = app.scaleImage(app.puzzleS, 2)
    app.image1 = app.loadImage('characters.png')
    app.boxHeight = 100
    app.boxWidth = 300
    app.margin = 100
    # The picture of the homepage comes from 
    #https://www.vecteezy.com/vector-art/7909878-abstract-green-maze-labyrinth-cartoon-style
    app.image2 = app.loadImage('homepage.png')
    app.level1 = False
    app.atHomePage = True
    # The coin pictures come from https://opengameart.org/content/rotating-coin-0
    app.image3 = app.loadImage('coins.png')
    app.level2 = False
    # The arrow pic comes from 
    # https://www.morewithprint.com/product/covid-19/wall-signage/arrow-wall-signage-12-inches/
    app.arrow = app.loadImage('backButton.png')
    app.backButton = app.scaleImage(app.arrow, 1/10)
    initMazeLevel1(app)
    initMazeLevel2(app)

def initMazeLevel1(app):
    app.maze = Maze(app.width, app.cellSize, app.rows, app.cols, app.margin)
    # the picture for puzzle boxes and the character comes from the same source
    # https://opengameart.org/content/a-platformer-in-the-forest
    app.puzzleC1 = [False, False, False]
    app.puzzles1 = Puzzles(app.imageBox, 3, 15, 15,app.cellSize, app.margin, app.imageBoxS, app.puzzleC1)
    app.puzzleAnswers1 = app.puzzles1.getSolutions()
    app.puzzleProblems1 = app.puzzles1.getPuzzles()
    app.sudokuC1 = [False, False]
    otherPositions1 = app.puzzles1.getPuzzlePositions()
    app.sudoku1 = Sudoku(app.imageBox, 2, 15, 15,app.cellSize, app.margin, app.imageBoxS, app.sudokuC1,otherPositions1)
    app.sudokuCurPos = None
    app.drawsudoku1 = [False,None]
    app.sudoku1DrawCell = None
    app.sudoku1FillNum = None
    app.sudoku1submit = None
    app.sudoku1Problems1 = app.sudoku1.getPuzzles()
    app.walls = app.maze.getWalls()
    entrance = (app.margin, app.margin + app.cellSize //2)
    app.character = Character(app.image1, app.walls, app.cellSize, entrance,app.rows, app.cols, app.margin)
    app.solution = mazeSolution(app.walls, app.cellSize,app.rows, app.cols, app.margin)
    app.drawSolution = False
    app.coin = Coin(app.image3, 15, app.rows, app.cols, app.cellSize, app.margin)
    app.scores = 0
    app.drawCoinSolution = False
    app.characterPosition = None
    app.nearestCoinPosition = None
    app.win1 = False

def initMazeLevel2(app):
    app.puzzleC2 = [False, False, False, False, False]
    app.puzzles2 = Puzzles(app.imageBox, 5, 18, 18,app.cellSize, app.margin, app.imageBoxS, app.puzzleC2)
    app.puzzleAnswers2 = app.puzzles2.getSolutions()
    app.puzzleProblems2 = app.puzzles2.getPuzzles()
    app.sudokuC2 = [False, False, False]
    otherPositions2 = app.puzzles1.getPuzzlePositions()
    app.sudoku2 = Sudoku(app.imageBox, 3, 18, 18,app.cellSize, app.margin, app.imageBoxS, app.sudokuC2,otherPositions2)
    app.sudokuCurPos2 = None
    app.drawsudoku2 = [False,None]
    app.sudoku2DrawCell = None
    app.sudoku2FillNum = None
    app.sudoku2submit = None
    app.sudoku2Problems2 = app.sudoku2.getPuzzles()
    app.ellerMaze = EllerMaze(18, 18, app.margin, app.cellSize)
    ellerWalls = app.ellerMaze.getWalls()
    app.solutionLevel2 = mazeSolution(ellerWalls, app.cellSize,18, 18, app.margin)
    entrance2 = (app.margin, app.margin + app.cellSize//2)
    app.characterLevel2 = Character(app.image1, ellerWalls,app.cellSize, entrance2,18,18,app.margin)
    app.coinLevel2 = Coin(app.image3, 15, 18, 18,app.cellSize, app.margin)
    app.drawSolutionEller = False
    app.drawCoinSolutionEller = False
    app.characterPositionEller = None
    app.nearestCoinPositionEller = None
    app.scores2 = 0
    app.win2 = False

def timerFired(app):
    if not app.win2:
        if app.level2:
            app.coinLevel2.timerFired()       
            app.characterPositionEller = app.characterLevel2.getCharacterPosition()
            positions = app.coinLevel2.getCoinPositions()
            row, col = app.characterPositionEller
            for rowC, colC in positions:
                if (rowC,colC) == (row, col):
                    if app.coinLevel2.positions !=[]:
                        app.coinLevel2.positions.remove((rowC,colC))
                        app.scores2 += 1
                        app.drawCoinSolutionEller = False
            findNearestCoin(app, row, col,app.coinLevel2.positions,app.solutionLevel2)
            if app.characterPositionEller == (17,17) and False not in app.puzzleC2 and False not in app.sudokuC2:
                app.win2 = True  
            if app.sudoku2submit != None:
                if app.sudoku2submit:
                    app.showMessage('Correct!')
                    app.sudoku2submit = None
                    index = app.sudoku2.getPuzzlePositions().index(app.characterPositionEller)
                    app.sudokuC2[index] = True
                else:
                    app.showMessage('Incorrect!')
                    app.sudoku2submit = None    
    if not app.win1: 
        if app.level1:
            app.coin.timerFired()    
            app.characterPosition = app.character.getCharacterPosition()
            positions = app.coin.getCoinPositions()
            row, col = app.characterPosition
            for rowC, colC in positions:
                if (rowC,colC) == (row, col):
                    if app.coin.positions != []:
                        app.coin.positions.remove((rowC,colC))
                        app.scores += 1
                        app.drawCoinSolution = False
            findNearestCoin(app, row, col, app.coin.positions,app.solution)
            for rowP,colP in app.puzzles1.getPuzzlePositions():
                if (rowP,colP) == (row, col):
                    app.drawPuzzleWindow1 = True
            if app.characterPosition == (14,14) and False not in app.puzzleC1 and False not in app.sudokuC1:
                app.win1 = True
            if app.sudoku1submit != None:
                if app.sudoku1submit:
                    app.showMessage('Correct!')
                    app.sudoku1submit = None
                    index = app.sudoku1.getPuzzlePositions().index(app.characterPosition)
                    app.sudokuC1[index] = True
                else:
                    app.showMessage('Incorrect!')
                    app.sudoku1submit = None


def findNearestCoin(app, row, col, positions,solution):
    shortest = None
    result = None
    for (rowC,colC) in positions:
        length = solution.getLength(row, col,rowC, colC)
        if shortest == None or length < shortest:
            shortest = length
            result = (rowC, colC)
    if app.level1:
        app.nearestCoinPosition = result
    if app.level2:
        app.nearestCoinPositionEller = result

def drawScore(app, canvas,score,x1,y1,x2,y2):
    image = app.coinLevel2.getCoinImage()
    canvas.create_image(x1,y1, 
                            image=ImageTk.PhotoImage(image))
    canvas.create_text(x2,y2, text = f': {score}', 
    font = 'Helvetica 15 bold', fill = 'black')

def redrawAll(app, canvas):
    if app.atHomePage:
        drawHomePage(app, canvas)
    if app.instruction:
        canvas.create_rectangle(0,0,900,900, fill = 'beige')
        canvas.create_text(450,400,
        text = ''' 
        •The goal of the game is to get out of the maze and unlock all boxes in the maze.

        •When you are at the box, you have two choices: solve the puzzle or pay 
         to unlock the box.

         If you choose to solve the puzzle, press ’s’.
         If you choose to pay for the box, each box can be paid by 5 coins 
         you have collected in the maze. Press ‘p’ for the payment.

        There are hints given in the game:
        1. Press ‘c’ for the hint of nearest coin.
        2. Press ‘h’ for the hint of the maze solution from the start point to 
        the exit, but remember that you have to unlock all boxes and get to the 
        exit to win the game!
        ''',
        font = 'Helvetica 20 bold', fill = 'black' )
        canvas.create_image(40,40,image=ImageTk.PhotoImage(app.backButton))
    if app.level1:
        canvas.create_rectangle(0,0,900,900, fill = 'beige')
        canvas.create_image(40,40,image=ImageTk.PhotoImage(app.backButton))
        if app.drawSolution:
            app.solution.drawMazeSolution(canvas, 0, 0, app.rows - 1, app.cols - 1)
        if app.drawCoinSolution:
            r1,c1 = app.characterPosition
            r2,c2 = app.nearestCoinPosition
            app.solution.drawMazeSolutionCoin(canvas,r1,c1,r2,c2)
        app.maze.drawMaze(canvas)
        app.coin.redrawAll(canvas)
        app.puzzles1.redrawAll(canvas)
        app.sudoku1.redrawAll(canvas)
        app.character.drawCharacter(canvas)
        drawScore(app, canvas, app.scores,750, 100,775, 100)
        if app.drawsudoku1[0] == True:
            app.sudoku1.drawBoard(canvas,app.drawsudoku1[1])
            if app.sudoku1DrawCell != None:
                row,col = app.sudoku1DrawCell
                app.sudoku1.colorCell(canvas,row,col)
                fillingProblem = app.sudoku1.fillingProblems[app.sudokuCurPos]
                app.sudoku1.drawFillingNum(canvas,fillingProblem)
        if app.win1:
            canvas.create_rectangle(app.margin,app.margin + 3 * app.cellSize, app.margin + 15 * app.cellSize, app.margin + 8 * app.cellSize, fill = 'yellow')
            canvas.create_text(app.margin + 7 * app.cellSize, app.margin + 5 * app.cellSize, text = 'Win!',font = 'Helvetica 25 bold', fill = 'black')
            canvas.create_text(app.margin + 7 * app.cellSize, app.margin + 6 * app.cellSize, text = "Press 'r' to restart the game.",font = 'Helvetica 20 bold', fill = 'black')

    if app.level2:
        canvas.create_rectangle(0,0,900,900, fill = 'beige')
        canvas.create_image(40,40,image=ImageTk.PhotoImage(app.backButton))
        if app.drawSolutionEller:
            app.solutionLevel2.drawMazeSolution(canvas, 0, 0, 17, 17)
        if app.drawCoinSolutionEller:
            r1,c1 = app.characterPositionEller
            r2,c2 = app.nearestCoinPositionEller
            app.solutionLevel2.drawMazeSolutionCoin(canvas,r1,c1,r2,c2)
        app.ellerMaze.drawMaze(canvas)
        app.coinLevel2.redrawAll(canvas)
        app.puzzles2.redrawAll(canvas)
        app.sudoku2.redrawAll(canvas)
        app.characterLevel2.drawCharacter(canvas)
        drawScore(app, canvas, app.scores2,750,80,775,80)
        if app.drawsudoku2[0] == True:
            app.sudoku2.drawBoard(canvas,app.drawsudoku2[1])
            if app.sudoku2DrawCell != None:
                row,col = app.sudoku2DrawCell
                app.sudoku2.colorCell(canvas,row,col)
                fillingProblem = app.sudoku2.fillingProblems[app.sudokuCurPos2]
                app.sudoku2.drawFillingNum(canvas,fillingProblem)
        if app.win2:
            canvas.create_rectangle(app.margin,app.margin + 5 * app.cellSize, app.margin + 18 * app.cellSize, app.margin + 10 * app.cellSize, fill = 'yellow')
            canvas.create_text(app.margin + 9 * app.cellSize, app.margin + 7 * app.cellSize, text = 'Win!',font = 'Helvetica 25 bold',fill = 'black')
            canvas.create_text(app.margin + 9 * app.cellSize, app.margin + 8 * app.cellSize, text = "Press 'r' to restart the game.",font = 'Helvetica 20 bold',fill = 'black')

def keyPressed(app, event):
    if app.win1:
        if event.key == 'r':
            initMazeLevel1(app)
    if app.win2:
        if event.key == 'r':
            initMazeLevel2(app)
    if app.level1:
        app.character.keyPressed(event)
    if app.level2:
        app.characterLevel2.keyPressed(event)
    if event.key == 'h':
        if app.level1:
            app.drawSolution = not app.drawSolution
        if app.level2:
            app.drawSolutionEller = not app.drawSolutionEller
    if event.key == 'c':
        if app.coin.positions != []:
            if app.level1:
                app.drawCoinSolution = not app.drawCoinSolution
        if app.coinLevel2.positions !=[]:
            if app.level2:
                app.drawCoinSolutionEller = not app.drawCoinSolutionEller
    if event.key == 's':
        if app.level2:
            if app.characterPositionEller in app.puzzles2.getPuzzlePositions():
                index = app.puzzles2.getPuzzlePositions().index(app.characterPositionEller)
                if app.puzzleC2[index] != True:
                    position = app.puzzles2.positions[index]
                    problem = app.puzzleProblems2[position]
                    answer =  app.getUserInput(problem)
                    if answer != app.puzzleAnswers2[position]:
                        app.showMessage('No!')
                    else:
                        app.showMessage('Correct!')
                        app.puzzleC2[index] = True
            if app.characterPositionEller in app.sudoku2.getPuzzlePositions():
                index = app.sudoku2.getPuzzlePositions().index(app.characterPositionEller)
                app.sudokuCurPos2 = app.sudoku2.positions[index]
                problem = app.sudoku2Problems2[app.sudokuCurPos2]
                app.drawsudoku2 = [True, problem]
        if app.level1:
            if app.characterPosition in app.puzzles1.getPuzzlePositions():
                index = app.puzzles1.getPuzzlePositions().index(app.characterPosition)
                if app.puzzleC1[index] != True:
                    position = app.puzzles1.positions[index]
                    problem = app.puzzleProblems1[position]
                    answer =  app.getUserInput(problem)
                    if answer != app.puzzleAnswers1[position]:
                        app.showMessage('No!')
                    else:
                        app.showMessage('Correct!')
                        app.puzzleC1[index] = True
            if app.characterPosition in app.sudoku1.getPuzzlePositions():
                index = app.sudoku1.getPuzzlePositions().index(app.characterPosition)
                app.sudokuCurPos = app.sudoku1.positions[index]
                problem = app.sudoku1Problems1[app.sudokuCurPos]
                app.drawsudoku1 = [True, problem]


    if app.drawsudoku1[0] == True:
        if app.sudoku1DrawCell != None:
            if event.key in {'1','2','3','4','5','6','7','8','9'}:
                row,col = app.sudoku1DrawCell
                fillingProblem = app.sudoku1.fillingProblems[app.sudokuCurPos]
                fillingProblem[(row,col)] = event.key
            if event.key == 'BackSpace':
                row,col = app.sudoku1DrawCell
                fillingProblem = app.sudoku1.fillingProblems[app.sudokuCurPos]
                fillingProblem[(row,col)] = ''
    if app.drawsudoku2[0] == True:
        if app.sudoku2DrawCell != None:
            if event.key in {'1','2','3','4','5','6','7','8','9'}:
                row,col = app.sudoku2DrawCell
                fillingProblem = app.sudoku2.fillingProblems[app.sudokuCurPos2]
                fillingProblem[(row,col)] = event.key
            if event.key == 'BackSpace':
                row,col = app.sudoku1DrawCell
                fillingProblem = app.sudoku2.fillingProblems[app.sudokuCurPos2]
                fillingProblem[(row,col)] = ''
    if event.key == 'p':
        if app.level2:
            if app.characterPositionEller in app.puzzles2.getPuzzlePositions():
                index = app.puzzles2.getPuzzlePositions().index(app.characterPositionEller)
                if app.puzzleC2[index] != True and app.scores2 >= 5:
                    app.showMessage('You have paid for this puzzle for 5 coins!')
                    app.scores2 -= 5
                    app.puzzleC2[index] = True
                if app.puzzleC2[index] != True and app.scores2 < 5:
                    app.showMessage('You need to collect more coins!')
            if app.characterPositionEller in app.sudoku2.getPuzzlePositions():
                index = app.sudoku2.getPuzzlePositions().index(app.characterPositionEller)
                if app.sudokuC2[index] != True and app.scores2 >= 5:
                    app.showMessage('You have paid for this puzzle for 5 coins!')
                    app.scores2 -= 5
                    app.sudokuC2[index] = True
                if app.sudokuC2[index] != True and app.scores2 < 5:
                    app.showMessage('You need to collect more coins!')
        if app.level1:
            if app.characterPosition in app.puzzles1.getPuzzlePositions():
                index = app.puzzles1.getPuzzlePositions().index(app.characterPosition)
                if app.puzzleC1[index] != True and app.scores >= 5:
                    app.showMessage('You have paid for this puzzle for 5 coins!')
                    app.scores -= 5
                    app.puzzleC1[index] = True
                if app.puzzleC1[index] != True and app.scores < 5:
                    app.showMessage('You need to collect more coins!')
            if app.characterPosition in app.sudoku1.getPuzzlePositions():
                index = app.sudoku1.getPuzzlePositions().index(app.characterPosition)
                if app.sudokuC1[index] != True and app.scores >= 5:
                    app.showMessage('You have paid for this puzzle for 5 coins!')
                    app.scores -= 5
                    app.sudokuC1[index] = True
                if app.sudokuC1[index] != True and app.scores < 5:
                    app.showMessage('You need to collect more coins!')



def mousePressed(app, event):
    if app.atHomePage:
        x1, y1, x2, y2 = getLevel1(app)
        if x1 <= event.x <=x2 and y1 <= event.y <= y2:
            app.level1 = True
            app.atHomePage = False
        x3,y3,x4,y4 = getLevel2(app)
        if x3 <= event.x <= x4 and y3 <= event.y <= y4:
            app.level2 = True
            app.atHomePage = False
        x5,y5,x6,y6 = getInstruction(app)
        if x5 <= event.x <= x6 and y5 <= event.y <= y6:
            app.instruction = True
            app.atHomePage = False
    if app.instruction:
        if 10 <= event.x <= 70 and 10 <= event.y <= 70:
            app.atHomePage = True
            app.instruction = False
    if app.level2:
        if 10 <= event.x <= 70 and 10 <= event.y <= 70:
            app.atHomePage = True
            app.level2 = False
        if app.drawsudoku2[0] == True:
            if app.sudoku2.selectCell(event,app.drawsudoku2[1]) != None:
                app.sudoku2DrawCell = app.sudoku2.selectCell(event,app.drawsudoku2[1])
            if app.sudoku2.closeWindow(event):
                app.drawsudoku2[0] = False
            if app.sudoku2.mouseSubmit(event):
                app.sudoku2submit = app.sudoku2.solutionCheck(app.sudokuCurPos2)
    if app.level1:
        if 10 <= event.x <= 70 and 10 <= event.y <= 70:
            app.atHomePage = True
            app.level1 = False
        if app.drawsudoku1[0] == True:
            if app.sudoku1.selectCell(event,app.drawsudoku1[1]) != None:
                app.sudoku1DrawCell = app.sudoku1.selectCell(event,app.drawsudoku1[1])
            if app.sudoku1.closeWindow(event):
                app.drawsudoku1[0] = False
            if app.sudoku1.mouseSubmit(event):
                app.sudoku1submit = app.sudoku1.solutionCheck(app.sudokuCurPos)
    
def playMaze():
    height = 900
    runApp(width = height, height = height)

playMaze()

