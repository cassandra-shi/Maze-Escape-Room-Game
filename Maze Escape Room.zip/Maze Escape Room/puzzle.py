from cmu_112_graphics import *
import random
from sudoku import *

class Puzzles:
    def __init__(self, image, num1, rows, cols, cellSize, margin, imageS, solve):
        self.puzzlePic = image
        self.solvePic = imageS
        self.solve = solve
        self.num = num1
        self.positions = []
        self.rows = rows
        self.cols = cols
        self.cellSize = cellSize
        self.margin = margin
        self.solutions = {}
        self.problems = {}
        self.generatePuzzlePosition()
     

    def generatePuzzlePosition(self):
        operators = ['+','-','*']
        for i in range(self.num):
            row = random.randint(0,self.rows - 1)
            col = random.randint(0,self.cols - 1)
            self.positions.append((row, col))
            num1 = random.randint(0,9)
            num2 = random.randint(0,9)
            operator = random.randint(0,2)
            problem = f'{num1} {operators[operator]} {num2}'
            self.problems[(row, col)] = problem
            if operator == 0:
                self.solutions[(row, col)] = (str(num1 + num2))
            elif operator == 1:
                self.solutions[(row, col)] = (str(num1 - num2))
            else:
                self.solutions[(row, col)] = (str(num1 * num2))
        

    def getPuzzlePositions(self):
        return self.positions
    
    def getPuzzles(self):
        return self.problems
    
    def getSolutions(self):
        return self.solutions

    def cellToPosition(self, row, col):
        x = self.margin + (col) * self.cellSize +  0.5 * self.cellSize
        y = self.margin + (row) * self.cellSize +  0.5 * self.cellSize
        return (x,y)

    def redrawAll(self, canvas):
        for index in range(len(self.positions)):
            row, col = self.positions[index]
            x,y = self.cellToPosition(row, col)
            if not self.solve[index]:
                canvas.create_image(x, y, 
                                image=ImageTk.PhotoImage(self.puzzlePic))
            else:
                canvas.create_image(x, y, 
                                image=ImageTk.PhotoImage(self.solvePic))
